<template>
   <div class="hello">
    <h1>{{ msg }}</h1>
    <h2>这个是login页面<br/></h2>
   </div> 
</template>

<script>
export default {
  name: 'login',
  data () {
    return {
      msg: 'Welcome to Your Vue.js App'
    }
  }
}
</script>


