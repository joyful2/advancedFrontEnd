<template>
   <div class="hello">
    <h1>{{ msg }}</h1>
    <h2>这个是regit页面<br/></h2>
   </div> 
</template>

<script>
export default {
  name: 'regit',
  data () {
    return {
      msg: 'Welcome to Your Vue.js App'
    }
  }
}
</script>


