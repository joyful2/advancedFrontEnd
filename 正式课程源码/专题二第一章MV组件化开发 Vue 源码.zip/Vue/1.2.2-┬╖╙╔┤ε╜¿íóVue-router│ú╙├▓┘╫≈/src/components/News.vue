<template>
   <div class="hello">
    <h1>{{ msg }}</h1>
    <h2>这个是News页面</h2>
   </div> 
</template>

<script>
export default {
  name: 'News',
  data () {
    return {
      msg: 'Welcome to Your Vue.js App'
    }
  }
}
</script>
