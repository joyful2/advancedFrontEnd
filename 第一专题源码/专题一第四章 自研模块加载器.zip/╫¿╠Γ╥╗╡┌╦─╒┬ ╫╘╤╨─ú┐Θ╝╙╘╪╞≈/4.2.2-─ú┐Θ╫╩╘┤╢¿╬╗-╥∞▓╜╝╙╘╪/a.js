define(function( require, exports, module){
	var age = "30";
	exports.age = age;
});