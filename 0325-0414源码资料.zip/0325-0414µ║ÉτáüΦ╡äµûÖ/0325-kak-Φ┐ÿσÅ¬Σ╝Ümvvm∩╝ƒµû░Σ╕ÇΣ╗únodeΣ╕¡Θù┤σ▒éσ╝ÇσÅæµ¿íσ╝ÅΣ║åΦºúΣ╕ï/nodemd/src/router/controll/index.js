var request=require('request');
var redis=require('redis');
function index(req,res){
  request({
      url:'http://localhost:3000/',
      methods:'GET'
  },function(error,response,body){
    if(!error&&response.statusCode==200){
        var data=JSON.parse(body);
        res.render('./index.art',data);
    }
  })
}
module.exports=index;