function index(req,res){
    //获取get参数
    console.log(req.body);
    res.render('./json1.art');
  }
  module.exports=index;