var express=require('express');
var router=express.Router();
var index=require('./controll/index.js')
var json1=require('./controll/json1.js')
router.get('/',index);
router.post('/json1',json1);
module.exports=router;