var request = require('request');
	request({
	    url: 'http://127.0.0.1:3300/json1',//请求路径
	    method: "POST",//请求方式，默认为get
	    headers: {//设置请求头
	        "content-type": "application/json",
	    },
	    body: JSON.stringify({a:123,b:123})//post参数字符串
	 }, function(error, response, body) {
	  
	});