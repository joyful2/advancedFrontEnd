var WC = (function(global, factory){
    return factory.call(global);
})(this, function(){
        var __TOOL__ = {};
        __TOOL__.registerComponet = function(tagName, document, callback){
            //第一步 获取对象 ？？ document --> index.html文档对象
            var indexDoc = document;
            //currentScript：获取 正在执行JS代码的 script标签对象
            //ownerDocument :以document对象返回 节点的ownerDocument
            var CurrentDoc = indexDoc.currentScript.ownerDocument; //获取wy-xin。html的文档对象

            var temp = CurrentDoc.getElementById(tagName);
            //console.log(temp); //

            //第二步 要注册元素   
            //定义了老子 以后新的元素 都要继承于我
            var xinProto = Object.create(HTMLElement.prototype);

            //第三步 显示组件
            xinProto.createdCallback = function(){

                //this ？？？ 谁被注册 this就代表 
                //console.log(this);
                //创建一个影子DOM  ???
                var root = this.createShadowRoot();
                //importNode 1. 要导入的节点 2. 是否复制所有的子孙节点 
                root.appendChild(indexDoc.importNode(temp.content, true));
                callback.call(this, root);
                
                //this.innerHTML = temp.innerHTML;
            }

            //第二步 要注册元素
            var xin = indexDoc.registerElement(tagName, {
                prototype : xinProto
            });
   

    }
    return __TOOL__;
});