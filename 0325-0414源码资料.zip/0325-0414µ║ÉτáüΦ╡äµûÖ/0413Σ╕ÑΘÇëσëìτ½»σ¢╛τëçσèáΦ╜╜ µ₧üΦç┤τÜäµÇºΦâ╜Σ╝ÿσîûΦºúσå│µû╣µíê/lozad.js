
(function (global, factory) {
  typeof exports === 'object' && typeof module !== 'undefined' ? module.exports = factory() :
  typeof define === 'function' && define.amd ? define(factory) :
  (global.lozad = factory());
}(this, (function () { 'use strict';

  var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

  /**
   * Detect IE browser
   * @const {boolean}
   * @private
   */
  var defaultConfig = {
    threshold: 0,    //threshold属性决定了什么时候触发回调函数。默认为[0],即交叉比例（intersectionRatio）达到0时触发回调函数。
    load: function load(element) {
      if (element.getAttribute('data-src')) {
        element.src = element.getAttribute('data-src');
      }
    },
  };

  function markAsLoaded(element) {
    element.setAttribute('data-loaded', true);
  }

  var isLoaded = function isLoaded(element) {
    return element.getAttribute('data-loaded') === 'true';
  };

  var onIntersection = function onIntersection(load) {
		//entries 数组形式 提供目标元素的信息  observer 实例对象
    return function (entries, observer) {
      entries.forEach(function (entry) {
				//目标元素与视口的交叉比完全可见时为1，完全不可见时小于等于0
        if ( entry.intersectionRatio > 0 ) {
          observer.unobserve(entry.target);
          //当前元素没有data-loaded属性 说明没有给src赋值重新加载。
          if (!isLoaded(entry.target)) {
            load(entry.target);
            markAsLoaded(entry.target);
          }
        }
      });
    };
  };

  var getElements = function getElements(selector) {
    if (selector instanceof Element) {
      return [selector];
    }
    if (selector instanceof NodeList) {
      return selector;
    }
    return document.querySelectorAll(selector);
  };

  function lozad () {
    var selector = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : '.lozad';
    var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};

    var _defaultConfig$option = _extends({}, defaultConfig, options),
        threshold = _defaultConfig$option.threshold,
        load = _defaultConfig$option.load;

    var observer = void 0;

    if (window.IntersectionObserver) {
      observer = new IntersectionObserver(onIntersection(load), {	
        threshold: threshold
      });
    }

    return {
      observe: function observe() {
        var elements = getElements(selector);

        for (var i = 0; i < elements.length; i++) {
          if (isLoaded(elements[i])) { // 检测当前元素是否有data-loaded 属性 有进入下次循环
            continue;
          }
          if (observer) {
            observer.observe(elements[i]);  //观察元素
            continue;
          }
					//如果observer 不存在的情况 类似延迟加载
          load(elements[i]);  // el.src = el.getAttribute("data-src");
          markAsLoaded(elements[i]);   //给elements[i] 设置data-loaded属性证明已经给它的src 赋值了。
          loaded(elements[i]);
        }
      },
      triggerLoad: function triggerLoad(element) {
        if (isLoaded(element)) {   // 检测当前元素是否有data-loaded 属性
          return;
        }
        load(element);
        markAsLoaded(element);
      },

      observer: observer
    };
  }

  return lozad;

})));
