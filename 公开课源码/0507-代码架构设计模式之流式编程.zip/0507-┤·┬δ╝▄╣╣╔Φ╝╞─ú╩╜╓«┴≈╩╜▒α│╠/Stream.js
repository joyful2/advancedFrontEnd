(function(root) {
	var _ = function(object) {
		this.wrap = object;
		if (!(this instanceof _)) {
			return new _(object);
		}
	}
	//  _.uniq().reduce();  1 1
	_.unique = function(arr, callback) {
		var result = [];  //去重之后的结果
		var i = 0;
		for (; i < arr.length;i++) {
            var target =  callback ? callback(arr[i]) : arr[i];
			if(result.indexOf(target) ===-1){
				result.push(target);
			}
		}
		return result;
	}

	//遍历
	_.each = function(arr, callback) {
		var len = arr && arr.length;
		for (var i = 0; i < len; i++) {
			callback.call(arr, arr[i]);
		}
	}
	
	_.map = function(args){
		console.log(args)   //  {wrap: undefined, _chain: true}   数据源
	}
	
	//开启链接式的调用
	_.chain = function(obj){
		var instance = _(obj);   //this.wrap = undefined
		instance._chain = true;     //属性
		return instance;
	}
	
	//辅助函数  instance 实例对象   obj  传递的数据流
	_.result = function(instance, obj){
		return instance._chain ? _(obj).chain() : obj;
	}

	//返回一个数组  存储了(属性  方法)
	_.functions = function(obj) {
		var result = [];
		for (var key in obj) {
			result.push(key);
		}
		return result;
	}

	//mixin 混入模式   检测扩展了哪些东西 （属性  方法）       原型对象    扩展
	_.mixin = function(obj) {
		_.each(_.functions(obj), function(key) {
			var func = obj[key];
			_.prototype[key] = function() {
			
				var args = [this.wrap];    //  [1,2,3,4,5,6,7,6,8,9,"a","A"]
				//数组合并  [this.wrap,function(){}]
				[].push.apply(args,arguments);   //push
				//console.log(arguments[0])  // function(){}
				//console.log(this.wrap)
				//目标源    回调函数  instance    结果   args     this.wrap   undefined
				return _.result(this, func.apply(this,args));
			}
		});
	}
	_.mixin(_);
	//cache
	root._ = _;
})(this);


/*
args.push(arguments);     //[this.wrap,function(){}]

*/
